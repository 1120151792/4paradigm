#!/bin/bash

set -x

if [ ! -f ~/.bashrc ];then
    touch ~/.bashrc
fi

if [ `grep -c "source <(kubectl completion bash)" /root/.bashrc` = '0' ]; then
    echo "source <(kubectl completion bash)" >> ~/.bashrc
fi

if [ `grep -c "source /etc/profile" /root/.bashrc` = '0' ]; then
    echo "source /etc/profile" >> ~/.bashrc
fi
is_command(){
    command -v "$1" > /dev/null
}

set_self_cluster(){
    kubectl config set-credentials self.admin --token="eyJhbGciOiJSUzI1NiIsImtpZCI6ImViNzdmYzcwZGE0YTUwZjk4ZDRiMDE1YmE5YzUzMTYzMDRlNWQ3ZmMiLCJ0eXAiOiJKV1QifQ.eyJqdGkiOiJmYTdiMmQzZS00NGNkLTQwOWUtYjE0NC1mOWMzOGFjNWFiNjYiLCJpYXQiOjE2NzExODU3MjksInR5cCI6IkFjY2Vzc1Rva2VuIiwiZW1haWwiOiJhZG1pbkBjcGFhcy5pbyJ9.IA-oBqgr1EfFhA7oa3cgyoc8xEZA2uB-jLHx99cZymqAgNIObp8YqSC0mgclb61G8DJNiYUEqLE0zNzQf_r8Aa4aV8_NYAWtpu0bxuagSgrlcZiUdHK1PbAnCvesBguc_jLpzVs63W09OsmzUG6P2GUwGi8-cwSXK-HCcYzELXuP2kJ-5MvfiNH1b_uKt2tjXzCaxRf09Tk4GBBWHWjXM1VHjTlpbnNGkzWmr91yhLuL5oj7M7p3rxbvUYbN3Bp38eSTWnJxKX5EZmFq25V-nb9emK-dtJRKAbvYJ_2gXL0bfwvWu39rFdChiz07HOMuC8QqrHvmqOzQdQQM5UirCw"
    kubectl config set-cluster "self.ecadevbj1a-test01" --insecure-skip-tls-verify=true
    kubectl config set clusters."self.ecadevbj1a-test01".server "https://10.213.107.192/kubernetes/ecadevbj1a-test01"
    kubectl config set-context "self.ecadevbj1a-test01" --user="self.admin" --cluster="self.ecadevbj1a-test01"
}

set_kube_cluster() {
    #create users and update token
    kubectl config set-credentials ${3}.admin --token="${2}"
    #create cluster,context and server
    clusters_str=$(curl -i -H 'content-type: application/json' -H 'Accept:application/json' -H "Authorization: Bearer ${2}" -X POST -d "{\"query\":{\"apiVersion\":\"cluster.alauda.io/v1alpha1\",\"kind\":\"ClusterModule\",\"limit\":-1}}"  ${1})
    clusters_str=$(echo $clusters_str| sed 's/,/\n/g' | grep "\"cpaas.io/cluster" | sed 's/"//g;s/cpaas.io\/cluster://g')

    clusters=($clusters_str)
    for name in "${clusters[@]}"; do
        kubectl config set-cluster "${3}.${name}" --insecure-skip-tls-verify=true
        kubectl config set clusters."${3}.${name}".server "https://cpaas.${3}.io/kubernetes/${name}"
        kubectl config set-context "${3}.${name}" --user="${3}.admin" --cluster="${3}.${name}"
    done  
}
 
#config kubeconfig
init_kube_config() {

    #set token for td,ms admin user
    if [ -n "$USER_TD_TOKEN" ]; then
        set_kube_cluster "http://cpaas.td.io/v1/query/list" $USER_TD_TOKEN "td" 
    fi
 
    if [ -n "$USER_MS_TOKEN" ]; then
        set_kube_cluster "http://cpaas.ms.io/v1/query/list" $USER_MS_TOKEN "ms" 
    fi

    set_self_cluster


}
# for HOME persist
[ ! -d "$HOME/go/bin" ] && mkdir -p $HOME/go/bin
cp -rf /usr/local/gopath-bin/* $HOME/go/bin

if [ ! -L "$HOME/sdk" ];then
    ln -s /usr/local/sdk $HOME/sdk
fi
# init custom
if [ ! -d "$HOME/.vscode-server" ]
then
    cp -rf /usr/local/vscode-server $HOME/.vscode-server
    mkdir -p $HOME/.ssh && touch $HOME/.ssh/authorized_keys
    echo "alias 'll=ls --color=auto -alF'" >> $HOME/.bashrc
    echo "alias 'ls=ls --color=auto'" >> $HOME/.bashrc
    echo "alias 'grep=grep --color=auto'" >> $HOME/.bashrc
    echo ". $HOME/.bashrc" >> $HOME/.bash_profile
    
    go env -w GOPROXY="https://yidongpingtai:AKCp8jRb9CCwFDcUDsbPG9sZh516cAss6jFDBchhTk5VViccNXs8sWhYEMQbCWhkrXuX7poR2@artifactory.ecad.evercloud.io/artifactory/api/go/cpaas-develop-golang-virtual"
    go env -w GOSUMDB="off"
    # needless
    go env -w GO111MODULE="on"
fi
cp -rf /usr/local/vscode-server/extensions/ $HOME/.vscode-server
# go customization
echo '-----BEGIN CERTIFICATE-----
MIIDuDCCAqCgAwIBAgIJALbUV6RnSeSQMA0GCSqGSIb3DQEBCwUAMHgxCzAJBgNV
BAYTAkNOMRAwDgYDVQQIDAdCRUlKSU5HMRAwDgYDVQQHDAdCRUlKSU5HMQ4wDAYD
VQQKDAVqZnJvZzENMAsGA1UECwwEenBrcDEmMCQGA1UEAwwdYXJ0aWZhY3Rvcnku
ZWNhZC5ldmVyY2xvdWQuaW8wHhcNMjIwMTI4MDcxODIyWhcNMzIwMTI2MDcxODIy
WjB5MQswCQYDVQQGEwJDTjEQMA4GA1UECAwHYmVpamluZzERMA8GA1UEBwwIXGJl
aWppbmcxDjAMBgNVBAoMBWpmcm9nMQ0wCwYDVQQLDAR6cGtwMSYwJAYDVQQDDB1h
cnRpZmFjdG9yeS5lY2FkLmV2ZXJjbG91ZC5pbzCCASIwDQYJKoZIhvcNAQEBBQAD
ggEPADCCAQoCggEBANxIqnXystIR5NUHbYMzEJfBI6VM5dHE537g+j7vRZBYP2uP
wHOq0yEEhOt2EOUZiXb0XmLdjQYbOQqVUPqJdwjDyELpLJMejTFXQXRK477xnArz
UrpO5xHBV/JlJNXeNVT2C+giKTrJgWLq0a2VeHI6ftTIYj35FmVlRVobHi5m6XgV
Apn0svM5wp8z70zY7bD8ytUcayTzSx3JejmLwoVJAYMpKIPe90DJCKv67IJkXE5u
hyG66GxDgN7bAWsJxEQwzPnJSbbH5xC8Up+BQKCPyYW7Uy0XO7uTXStOGwrHg/d9
x1zL65gTIN2q7oS5Om6GgUqKITQYXGA5N76Od40CAwEAAaNEMEIwCQYDVR0TBAIw
ADALBgNVHQ8EBAMCBeAwKAYDVR0RBCEwH4IdYXJ0aWZhY3RvcnkuZWNhZC5ldmVy
Y2xvdWQuaW8wDQYJKoZIhvcNAQELBQADggEBAD74Qx8K0DdLLeF1AJWMLs/djVQb
ax7og7lmyDlrsfbi5ngYiWJz9Ggg69UmN9xxwK1un/EYDmmn0qL1n3JNxkOd+/b5
+HFI9QONPcG3gQ0ocy9f3kbWww3xZLTa3ziEzRU9NlNY1FEpDRxKmoN3G6Hh9aaN
4CXElOZ+oNYgrIC4fTItPHoTP3TeMYzwmg9Ym0yy73p4qqpOsyIv+W3x3hkKLlai
FCmd7NKQnZPMJeo9YD0OxxpR9+x4yf+wYAF/cSKEBC7EJe+BxFAx0HRUU61o8IZI
/C4XuQTRNlsxF6DZz5qMJcmP1tlyHgjADCWNrG9+BJJ2WeVMK0g57v4khY4=
-----END CERTIFICATE-----
' > /usr/local/share/ca-certificates/artifactory.crt

update-ca-certificates

# apt repos customization
if is_command kubectl; then
    init_kube_config
else
   echo "kubectl not a command, kubeconfig init failure"
fi

# change Port of SSH
sed -i 's/^#Port .*/Port 6622/g' /etc/ssh/sshd_config
sed -i 's/^#StrictModes .*/StrictModes no/g' /etc/ssh/sshd_config

#startup telnet
/etc/init.d/openbsd-inetd restart

# startup sshd
/usr/sbin/sshd -D